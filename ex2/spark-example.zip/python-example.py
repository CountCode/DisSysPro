#!/usr/bin/env python
#
# This script gives an example for the second assignment in DSP2015.
# Note that a Spark context depends on specific platform and settings.
# Please modify this file and play with it to get familiar with Spark.
#
# Liang Wang @ CS Dept, Helsinki University, Finland
# 2015.01.19 (modified 2016.01.27)
#

import os
import sys

#from pyspark import SparkConf, SparkContext


### Two data sets we will use, along with two samples
DATA1 = 'test-sample'

### Some variables you may want to personalize
AppName = "example"
TMPDIR = "/cs/work/scratch/spark-tmp"

### Creat a Spark context on Ukko cluster
from pyspark import SparkConf, SparkContext
conf = (SparkConf()
        .setMaster("spark://ukko080:7077")
        .setAppName(AppName)
        .set("spark.rdd.compress", "true")
        .set("spark.broadcast.compress", "true")
        .set("spark.cores.max", 10)  # do not be greedy :-)
        .set("spark.local.dir", TMPDIR))
sc = SparkContext(conf = conf)

### Put your algorithm here.

def calculate_average(fn):
    data = sc.textFile(fn)
    data = data.map(lambda s: float(s))
    myAvg = data.sum() / data.count()
    return myAvg


if __name__=="__main__":
    myAvg = calculate_average(DATA1)
    print "Avg. = %.8f" % myAvg

    sys.exit(0)

